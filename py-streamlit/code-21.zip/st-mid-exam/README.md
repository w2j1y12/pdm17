# pdmnn
> 제출파일명: st-mid-pdmnn.py
## mid-exam: streamlit project of ----- data 
> ---- data 웹앱 프로젝트에 반영한 내용을 아래에 추가...
1. ----
2. ----